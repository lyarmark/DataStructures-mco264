package balancedBinaryTree;

public interface ProtectedData {
	public abstract ProtectedData clone();
	

}
