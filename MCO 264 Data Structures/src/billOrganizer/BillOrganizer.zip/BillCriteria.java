package billOrganizer;

public enum BillCriteria {
	BILLDUEDATE, BILLAMOUNT, BILLTYPE
}
