package billOrganizer;

public enum BillType {
	CLOTHING, EDUCATION, FOOD, GROCERIES, PHONE, TRAVEL, UTILITIES
}
