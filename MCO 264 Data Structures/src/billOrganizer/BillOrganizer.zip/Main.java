package billOrganizer;

public class Main {

	public static void main(String[] args) {
		JFrameMenu jFrame = new JFrameMenu();
		jFrame.setVisible(true);
	}

}
