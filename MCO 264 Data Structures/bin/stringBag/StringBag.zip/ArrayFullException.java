package stringBag;

public class ArrayFullException extends Exception {
	public ArrayFullException() {
		super("The bag is full");
	}
}
