package stringBag;

public class ArrayEmptyException extends Exception {
	public ArrayEmptyException() {
		super("Array is empty");
	}
}
