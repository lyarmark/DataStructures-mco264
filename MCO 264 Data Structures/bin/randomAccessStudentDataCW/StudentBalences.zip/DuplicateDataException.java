package randomAccessStudentDataCW;

public class DuplicateDataException extends Exception{
	public DuplicateDataException (){
		super ("duplicate data");
	}

}
